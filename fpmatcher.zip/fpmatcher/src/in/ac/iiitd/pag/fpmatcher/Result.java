package in.ac.iiitd.pag.fpmatcher;

public class Result {
	public String level;	
	public double precision;
	public double recall;	
}
