package in.ac.iiitd.pag.fpmatcher;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

public class FPMatcher {
	
	public static String inputPathBinaryFP = "C:\\data\\icse2018nier\\data\\new\\extra";
	public static String outputResultsFilePath = "C:\\data\\icse2018nier\\data\\results.csv";
	public static String outputPrecisionResultsFilePath = "C:\\data\\icse2018nier\\data\\precisionResults.csv";
	public static String outputRecallResultsFilePath = "C:\\data\\icse2018nier\\data\\recallResults.csv";
	public static HashMap<String, Double> results = new HashMap<String, Double>();
	public static HashMap<String, HashMap<String, Double>> resultsPerMathFP = new HashMap<String, HashMap<String, Double>>();
	public static DecimalFormat df = new DecimalFormat();
	
	
	public static void main(String[] args) {
		df.setMaximumFractionDigits(2);
		for(double i=0.4; i<0.5; i+=0.05) {
			double matchCutoff = i;
			match(matchCutoff);
			try {
				HashMap<String, Double> precisionResults = calculatePrecision(outputResultsFilePath, getAllMathFP().keySet());
				saveAsCSV1(precisionResults, outputPrecisionResultsFilePath);
				HashMap<String, Double> recallResults = calculateRecall(outputResultsFilePath, getAllMathFP().keySet());
				saveAsCSV1(recallResults, outputRecallResultsFilePath);
				HashMap<String, Double> FScore = computeFScore(precisionResults, recallResults, getAllMathFP().keySet());
				double FScoreVal = 0.0;
				for(String key: getAllMathFP().keySet()) {
					FScoreVal = FScoreVal + FScore.get(key);
				}
				
				System.out.println(df.format(matchCutoff) + ":" + df.format(FScoreVal / FScore.size()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
	}

	

	private static HashMap<String, Double> computeFScore(
			HashMap<String, Double> precisionResults,
			HashMap<String, Double> recallResults, Set<String> mathExpns) {
		HashMap<String, Double> FScore = new HashMap<String, Double>();
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		
		for(String key: mathExpns) {
			double p = precisionResults.get(key.toLowerCase());
			double r = recallResults.get(key.toLowerCase());			
			Double f = 2*p*r/(p+r);
			if (f.isNaN()) f = 0.0;
			FScore.put(key, f);
			
			System.out.println(key + ":" + df.format(p) + "," + df.format(r) + "," + df.format(f));
		}
		return FScore;
	}



	private static void match(double cutoff) {
		HashMap<String, String> allMathFPMap = getAllMathFP();
		Set<String> allMathFP = getAllMathFP().keySet();
		File[] files = new File(inputPathBinaryFP).listFiles();
		
		for(String mathFP: allMathFP) {
			results = new HashMap<String, Double>();
			for(File file: files) {
				if (getFileExtension(file).equalsIgnoreCase("txt")) {					
					List<String> allFPOfASingleBinary = getAllFP(file.getAbsolutePath());
					double found = 0;
					for(String fp: allFPOfASingleBinary) {
						String efp = allMathFPMap.get(mathFP);
						String matchedSeq = LCS.lcs(fp, efp);
						
						matchedSeq = matchedSeq.replace(" ", "");
						/*if (file.getName().equalsIgnoreCase("Sigmoid2_Reduced_Cleaned_Strings.txt") &&  matchedSeq.equalsIgnoreCase("e+") && efp.equalsIgnoreCase("e+/")) {
							System.out.println(efp);
						}*/
						double percentMatch = matchedSeq.length() * 1.0 / efp.length();
						
						if (percentMatch >= cutoff) {
							found = 1;
							break;
						};
					}
					results.put(file.getName(), found);
					found = 0.0;
				}
			}
			resultsPerMathFP.put(mathFP.toLowerCase(), results);
		}
		
		saveAsCSV(resultsPerMathFP, outputResultsFilePath);
	}
	
	private static String getLevel(String name) {
		if (name.contains("gcc0")) return "gcc0";
		if (name.contains("gcc2")) return "gcc2";
		if (name.contains("gccs")) return "gccs";
		return "";
	}
	
	private static void saveAsCSV1(HashMap<String, Double> precisionResults,
			String outputPrecisionResultsFilePath2) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	              new FileOutputStream(outputPrecisionResultsFilePath2), "utf-8"))) {
			Set<String> keys = precisionResults.keySet();
			for(String key: keys) {				
				writer.write(key + "," + precisionResults.get(key) + "\n");				
			}
			writer.close();			
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public static void saveAsCSV(HashMap<String, HashMap<String, Double>> map, String outputFilePath) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	              new FileOutputStream(outputFilePath), "utf-8"))) {
			Set<String> keys = map.keySet();
			for(String key: keys) {
				HashMap<String, Double> resultsMap = map.get(key);
				Set<String> resultsKeys = resultsMap.keySet();
				for(String resultsKey: resultsKeys) {
					writer.write(key + "," + resultsKey + "," +  resultsMap.get(resultsKey) + "\n");
				}
			}
			writer.close();			
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private static String getFileExtension(File file) {
	    String name = file.getName();
	    try {
	        return name.substring(name.lastIndexOf(".") + 1).toLowerCase();
	    } catch (Exception e) {
	        return "";
	    }
	}

	
	public static HashMap<String, String> getAllMathFP() {
		HashMap<String, String> mathFP = new HashMap<String, String>();
		mathFP.put("heron", "-*-*-*q");
		//mathFP.put("quad", "-^**-q+*/");
		//mathFP.put("cylinder", "^**");
		mathFP.put("ci",  "/+^*");
		//mathFP.put("deg2rad",  "/*");
		mathFP.put("sigmoid", "e+/");
		mathFP.put("black", "/l^/+-*+q*/");
		return mathFP;
	}
	
	/**
	 * For each file, let us pull out all the function fp strings.
	 * @param filePath
	 * @return
	 */
	public static List<String> getAllFP(String filePath) {
		List<String> fnFPs = new ArrayList<String>();
		try {
			
			FileInputStream fstream = new FileInputStream(filePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			String line = "";
			while ((line = br.readLine()) != null) {
				 if (line.trim().length() > 0) {
					 fnFPs.add(line);
				 }
			}
			
			br.close();
			fstream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return fnFPs;
        
	}
	

	public static HashMap<String, Double> calculatePrecision(String outputResultsFilePath, Set<String> mathExpns) throws IOException {
		HashMap<String, Double> precisionMap = new HashMap<String, Double>();
		
		for (String mathExpn: mathExpns) {
		
			HashMap<String, Double> tpMath = new HashMap<String, Double>();
			HashMap<String, Double> fpMath = new HashMap<String, Double>();
			tpMath.put(mathExpn, 0.0);
			fpMath.put(mathExpn, 0.0);
			
			FileInputStream fstream = new FileInputStream(outputResultsFilePath);
	        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
	        String line = "";
	       
	        
			while ((line = br.readLine()) != null) {
				 if (line.trim().length() > 0) {
					 String[] items = line.split(",");
					 
					 String expName = items[0].toLowerCase();				 
					 if (!expName.equalsIgnoreCase(mathExpn)) continue;
					 
					 String mathName = getItemMathName(items[1]).toLowerCase();					 
					 Double value = Double.parseDouble(items[2]);
					 
					 double tp = 0.0;
				     double fp = 0.0;
					 
					 if (mathName.equalsIgnoreCase(expName) && (value == 1.0)) {
						 tp = 1.0;
					 }
					 if (!mathName.equalsIgnoreCase(expName) && (value == 1.0)) {
						 fp = 1.0;
					 } 
					 
					 if (tpMath.containsKey(mathExpn)) {
						 value = tpMath.get(mathExpn) + tp;
					 }
					 tpMath.put(mathExpn, value);
					 
					 if (fpMath.containsKey(mathExpn)) {
						 value = fpMath.get(mathExpn) + fp;
					 }
					 fpMath.put(mathExpn, value);
				 }
			}
			
			
			double tp1 = 0.0;
			if (tpMath.containsKey(mathExpn))
				tp1 = tpMath.get(mathExpn);
			double fp1 = 0.0;
			if (fpMath.containsKey(mathExpn)) 
				fp1 = fpMath.get(mathExpn);
			Double precision = tp1 / (tp1 + fp1);
			if (precision.isNaN()) precision = 0.0;
			precisionMap.put(mathExpn, precision);
			
			
			br.close();
			fstream.close();
		}
		return precisionMap;
	}
	
	public static HashMap<String, Double> calculateRecall(String outputResultsFilePath, Set<String> mathExpns) throws IOException {
		HashMap<String, Double> recallMap = new HashMap<String, Double>();
		
		for(String mathExpn: mathExpns) {
			
			HashMap<String, Double> tpMath = new HashMap<String, Double>();
			HashMap<String, Double> fnMath = new HashMap<String, Double>();
			tpMath.put(mathExpn, 0.0);
			fnMath.put(mathExpn, 0.0);
			
			FileInputStream fstream = new FileInputStream(outputResultsFilePath);
	        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
	        String line = "";
	        double tp = 0.0;
	        double fn = 0.0;
			while ((line = br.readLine()) != null) {
				 if (line.trim().length() > 0) {
					 String[] items = line.split(",");
					 
					 String expName = items[0].toLowerCase();				 
					 if (!expName.equalsIgnoreCase(mathExpn)) continue;
					 
					 String mathName = getItemMathName(items[1]).toLowerCase();
					 Double value = Double.parseDouble(items[2]);
					 
					 if (mathName.equalsIgnoreCase(expName) && (value == 1.0)) {
						 tp = 1.0;
					 }
					 if (mathName.equalsIgnoreCase(expName) && (value == 0.0)) {
						 fn = 1.0;
					 } 
					 
					 if (tpMath.containsKey(mathName)) {
						 value = tpMath.get(mathName) + tp;
					 }
					 tpMath.put(mathName, value);
					 
					 if (fnMath.containsKey(mathName)) {
						 value = fnMath.get(mathName) + fn;
					 }
					 fnMath.put(mathName, value);
				 }
			}
			
			
			double tp1 = 0.0;
			if (tpMath.containsKey(mathExpn))
				tp1 = tpMath.get(mathExpn);
			double fn1 = 0.0;
			if (fnMath.containsKey(mathExpn))
				fn1 = fnMath.get(mathExpn);
			Double recall = tp1 / (tp1 + fn1);
			if (recall.isNaN()) recall = 0.0;
			recallMap.put(mathExpn, recall);
			
			
			br.close();
			fstream.close();
		}
		return recallMap;
	}

	private static String getItemMathName(String filename) {
		int index = filename.indexOf("_");
		try {
			Integer.parseInt(filename.substring(index -1, index));
			index = index -1;
		} catch (Exception e) {
			
		}
		
		String mathName = filename.substring(0, index);
		return mathName;
	}
}
