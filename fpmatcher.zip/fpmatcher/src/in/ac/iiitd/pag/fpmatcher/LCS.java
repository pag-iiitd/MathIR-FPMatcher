package in.ac.iiitd.pag.fpmatcher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class LCS {
	
	public static String[] operators = {"^","l","e","q","/","*", "+", "-", "%"};
	
	/**
	 * str1 is the bfp. str2 is the efp.
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static String lcs(String str1, String str2) {

		Set<String> notInEFPOps = new HashSet<String>();
		for (int i=0; i<operators.length; i++) {
			if (!str2.contains(operators[i])) {
				notInEFPOps.add(operators[i]);
			}
		}
		int irrelevantOps = 0;
		for(String op: notInEFPOps) {
			if (str1.contains(op)) {
				irrelevantOps++;
			}
		}
		if (irrelevantOps*100.0/str1.length() > 25) return "";
		if (str1.length() > str2.length()*2.2) return "";
				
        int l1 = str1.length();
        int l2 = str2.length();

        int[][] arr = new int[l1 + 1][l2 + 1];
        int len = 0, pos = -1;

        for (int x = 1; x < l1 + 1; x++) {

            for (int y = 1; y < l2 + 1; y++) {

                if (str1.charAt(x - 1) == str2.charAt(y - 1)) {

                    arr[x][y] = arr[x - 1][y - 1] + 1;

                    if (arr[x][y] > len) {

                        len = arr[x][y];

                        pos = x;

                    }

                } else {
                    arr[x][y] = 0;
                }

            }

        }

        if (pos >= 0) {
            return str1.substring(pos - len, pos);
        } else {
            return "";
        }
    }
}
